/*
 * OptimalSlidingMode_acc_data.c
 *
 * Real-Time Workshop code generation for Simulink model "OptimalSlidingMode_acc.mdl".
 *
 * Model Version              : 1.36
 * Real-Time Workshop version : 7.4  (R2009b)  29-Jun-2009
 * C source code generated on : Fri Dec 11 23:57:09 2015
 *
 * Target selection: accel.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Emulation hardware selection:
 *    Differs from embedded hardware (MATLAB Host)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "OptimalSlidingMode_acc.h"
#include "OptimalSlidingMode_acc_private.h"

/* Block parameters (auto storage) */
Parameters rtDefaultParameters = {
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S3>/disurbance'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S3>/disurbance'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S3>/disurbance'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S3>/disurbance'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S3>/Constant'
                                        */
  0.0003,                              /* Expression: .0003
                                        * Referenced by: '<S10>/Integrator1'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S8>/Sine Wave1'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S8>/Sine Wave1'
                                        */
  1.5707963267948966E+000,             /* Expression: pi/2
                                        * Referenced by: '<S8>/Sine Wave1'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S8>/Sine Wave1'
                                        */
  1.5701963267948966E+000,             /* Expression: pi/2 - 0.0006
                                        * Referenced by: '<S10>/Integrator'
                                        */
  1.5707963267948966E+000,             /* Expression: pi/2
                                        * Referenced by: '<S8>/Sine Wave2'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S8>/Sine Wave2'
                                        */
  1.5707963267948966E+000,             /* Expression: pi/2
                                        * Referenced by: '<S8>/Sine Wave2'
                                        */
  1.5707963267948966E+000,             /* Expression: pi/2
                                        * Referenced by: '<S8>/Sine Wave2'
                                        */
  20.0,                                /* Expression: 20
                                        * Referenced by: '<S7>/Constant  20'
                                        */
  -2.0,                                /* Expression: -2
                                        * Referenced by: '<S7>/Switch'
                                        */
  -2.4674011002723395E+000,            /* Expression: -(pi/2)*(pi/2)
                                        * Referenced by: '<S8>/Sine Wave3'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S8>/Sine Wave3'
                                        */
  1.5707963267948966E+000,             /* Expression: pi/2
                                        * Referenced by: '<S8>/Sine Wave3'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S8>/Sine Wave3'
                                        */
  -3.0,                                /* Expression: -3
                                        * Referenced by: '<S11>/Constant  20'
                                        */
  1U,                                  /* Expression: uint8(1)
                                        * Referenced by: '<S5>/Constant'
                                        */
  1U,                                  /* Expression: uint8(1)
                                        * Referenced by: '<S5>/SwitchControl'
                                        */

  { 'a', 'a', 'a', 'a', 'a', 'a' }     /* Expression: uint8(1)
                                        * Referenced by: '<S5>/SwitchControl'
                                        */
};
