/*
 * OptimalSlidingMode_acc.h
 *
 * Real-Time Workshop code generation for Simulink model "OptimalSlidingMode_acc.mdl".
 *
 * Model Version              : 1.36
 * Real-Time Workshop version : 7.4  (R2009b)  29-Jun-2009
 * C source code generated on : Fri Dec 11 23:57:09 2015
 *
 * Target selection: accel.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Emulation hardware selection:
 *    Differs from embedded hardware (MATLAB Host)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */
#ifndef RTW_HEADER_OptimalSlidingMode_acc_h_
#define RTW_HEADER_OptimalSlidingMode_acc_h_
#ifndef OptimalSlidingMode_acc_COMMON_INCLUDES_
# define OptimalSlidingMode_acc_COMMON_INCLUDES_
#include <stdlib.h>
#include <stddef.h>
#define S_FUNCTION_NAME                simulink_only_sfcn
#define S_FUNCTION_LEVEL               2
#define RTW_GENERATED_S_FUNCTION
#include "rtwtypes.h"
#include "simstruc.h"
#include "fixedpoint.h"
#include "mwmathutil.h"
#include "rt_nonfinite.h"
#endif                                 /* OptimalSlidingMode_acc_COMMON_INCLUDES_ */

#include "OptimalSlidingMode_acc_types.h"

/* Block signals (auto storage) */
typedef struct {
  real_T B_2_2_0;                      /* '<S3>/Constant' */
  real_T B_2_3_0;                      /* '<S3>/Sum' */
  real_T B_2_6_0;                      /* '<S8>/Sine Wave1' */
  real_T B_2_7_0;                      /* '<Root>/Fcn' */
  real_T B_2_8_0;                      /* '<S10>/Integrator' */
  real_T B_2_9_0;                      /* '<S8>/Sine Wave2' */
  real_T B_2_10_0;                     /* '<Root>/Fcn1' */
  real_T B_2_12_0;                     /* '<S7>/system1' */
  real_T B_2_16_0;                     /* '<S7>/Constant  20' */
  real_T B_2_17_0;                     /* '<S7>/Switch' */
  real_T B_2_21_0;                     /* '<S6>/system1' */
  real_T B_2_22_0;                     /* '<S5>/SwitchControl' */
  real_T B_2_25_0;                     /* '<S8>/Sine Wave3' */
  real_T B_2_32_0;                     /* '<S2>/control' */
  real_T B_2_35_0;                     /* '<S10>/system' */
  real_T B_1_3_0[2];                   /* 'synthesized block' */
  real_T B_0_0_0;                      /* '<S11>/Constant  20' */
  uint8_T B_2_18_0;                    /* '<S5>/Constant' */
  uint8_T B_2_19_0;                    /* '<S5>/S-Function' */
  char pad_B_2_19_0[6];
} BlockIO;

/* Block states (auto storage) for system '<Root>' */
typedef struct {
  struct {
    void *LoggedData;
  } Disturbance_PWORK;                 /* '<Root>/Disturbance' */

  struct {
    void *LoggedData;
  } ErrorsandLanda_PWORK;              /* '<Root>/Errors and Landa' */

  struct {
    void *LoggedData;
  } L_PWORK;                           /* '<Root>/L' */

  struct {
    void *LoggedData;
  } REFs_PWORK;                        /* '<Root>/REFs' */

  struct {
    void *LoggedData;
  } e_PWORK;                           /* '<Root>/e' */

  struct {
    void *LoggedData;
  } ed_PWORK;                          /* '<Root>/ed' */

  struct {
    void *LoggedData;
  } u_PWORK;                           /* '<Root>/u' */

  struct {
    void *LoggedData;
  } Scope_PWORK;                       /* '<S7>/Scope' */

  int8_T If_ActiveSubsystem;           /* '<S7>/If' */
  int8_T IfActionSubsystem_SubsysRanBC;/* '<S7>/If Action Subsystem' */
  char pad_IfActionSubsystem_SubsysRanBC[6];
} D_Work;

/* Continuous states (auto storage) */
typedef struct {
  real_T Integrator1_CSTATE;           /* '<S10>/Integrator1' */
  real_T Integrator_CSTATE;            /* '<S10>/Integrator' */
} ContinuousStates;

/* State derivatives (auto storage) */
typedef struct {
  real_T Integrator1_CSTATE;           /* '<S10>/Integrator1' */
  real_T Integrator_CSTATE;            /* '<S10>/Integrator' */
} StateDerivatives;

/* State disabled  */
typedef struct {
  boolean_T Integrator1_CSTATE;        /* '<S10>/Integrator1' */
  boolean_T Integrator_CSTATE;         /* '<S10>/Integrator' */
} StateDisabled;

/* Parameters (auto storage) */
struct Parameters_ {
  real_T P_0;                          /* Expression: 1
                                        * Referenced by: '<S3>/disurbance'
                                        */
  real_T P_1;                          /* Expression: 0
                                        * Referenced by: '<S3>/disurbance'
                                        */
  real_T P_2;                          /* Expression: 1
                                        * Referenced by: '<S3>/disurbance'
                                        */
  real_T P_3;                          /* Expression: 0
                                        * Referenced by: '<S3>/disurbance'
                                        */
  real_T P_4;                          /* Expression: 1
                                        * Referenced by: '<S3>/Constant'
                                        */
  real_T P_5;                          /* Expression: .0003
                                        * Referenced by: '<S10>/Integrator1'
                                        */
  real_T P_6;                          /* Expression: 1
                                        * Referenced by: '<S8>/Sine Wave1'
                                        */
  real_T P_7;                          /* Expression: 0
                                        * Referenced by: '<S8>/Sine Wave1'
                                        */
  real_T P_8;                          /* Expression: pi/2
                                        * Referenced by: '<S8>/Sine Wave1'
                                        */
  real_T P_9;                          /* Expression: 0
                                        * Referenced by: '<S8>/Sine Wave1'
                                        */
  real_T P_10;                         /* Expression: pi/2 - 0.0006
                                        * Referenced by: '<S10>/Integrator'
                                        */
  real_T P_11;                         /* Expression: pi/2
                                        * Referenced by: '<S8>/Sine Wave2'
                                        */
  real_T P_12;                         /* Expression: 0
                                        * Referenced by: '<S8>/Sine Wave2'
                                        */
  real_T P_13;                         /* Expression: pi/2
                                        * Referenced by: '<S8>/Sine Wave2'
                                        */
  real_T P_14;                         /* Expression: pi/2
                                        * Referenced by: '<S8>/Sine Wave2'
                                        */
  real_T P_15;                         /* Expression: 20
                                        * Referenced by: '<S7>/Constant  20'
                                        */
  real_T P_16;                         /* Expression: -2
                                        * Referenced by: '<S7>/Switch'
                                        */
  real_T P_17;                         /* Expression: -(pi/2)*(pi/2)
                                        * Referenced by: '<S8>/Sine Wave3'
                                        */
  real_T P_18;                         /* Expression: 0
                                        * Referenced by: '<S8>/Sine Wave3'
                                        */
  real_T P_19;                         /* Expression: pi/2
                                        * Referenced by: '<S8>/Sine Wave3'
                                        */
  real_T P_20;                         /* Expression: 0
                                        * Referenced by: '<S8>/Sine Wave3'
                                        */
  real_T P_21;                         /* Expression: -3
                                        * Referenced by: '<S11>/Constant  20'
                                        */
  uint8_T P_22;                        /* Expression: uint8(1)
                                        * Referenced by: '<S5>/Constant'
                                        */
  uint8_T P_23;                        /* Expression: uint8(1)
                                        * Referenced by: '<S5>/SwitchControl'
                                        */
  char pad_P_23[6];
};

extern Parameters rtDefaultParameters; /* parameters */

#endif                                 /* RTW_HEADER_OptimalSlidingMode_acc_h_ */
