/*
 * This file is not available for use in any application other than as a
 * MATLAB(R) MEX file for use with the Simulink(R) product.
 */

/*
 * OptimalSlidingMode_acc.c
 *
 * Real-Time Workshop code generation for Simulink model "OptimalSlidingMode_acc.mdl".
 *
 * Model Version              : 1.36
 * Real-Time Workshop version : 7.4  (R2009b)  29-Jun-2009
 * C source code generated on : Fri Dec 11 23:57:09 2015
 *
 * Target selection: accel.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Emulation hardware selection:
 *    Differs from embedded hardware (MATLAB Host)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */
#include <math.h>
#include "OptimalSlidingMode_acc.h"
#include "OptimalSlidingMode_acc_private.h"
#include <stdio.h>
#include "simstruc.h"
#include "fixedpoint.h"
#define CodeFormat                     S-Function
#define AccDefine1                     Accelerator_S-Function

/* Outputs for root system: '<Root>' */
static void mdlOutputs(SimStruct *S, int_T tid)
{
  /* local block i/o variables */
  real_T B_2_31_0;

  {
    real_T B_2_5_0;
    int8_T rtAction;
    if (ssIsSampleHit(S, 1, 0)) {
      ((BlockIO *) _ssGetBlockIO(S))->B_2_2_0 = ((Parameters *)
        ssGetDefaultParam(S))->P_4;
    }

    ((BlockIO *) _ssGetBlockIO(S))->B_2_3_0 = muDoubleScalarAbs
      (muDoubleScalarSin(((Parameters *) ssGetDefaultParam(S))->P_2 *
                         ssGetTaskTime(S,0) + ((Parameters *) ssGetDefaultParam
         (S))->P_3) * ((Parameters *) ssGetDefaultParam(S))->P_0 + ((Parameters *)
        ssGetDefaultParam(S))->P_1) + ((BlockIO *) _ssGetBlockIO(S))->B_2_2_0;
    if (ssIsSampleHit(S, 1, 0)) {
      /* Scope: '<Root>/Disturbance' */
      /* Call into Simulink for Scope */
      ssCallAccelRunBlock(S, 2, 4, SS_CALL_MDL_OUTPUTS);
    }

    B_2_5_0 = ((ContinuousStates *) ssGetContStates(S))->Integrator1_CSTATE;
    ((BlockIO *) _ssGetBlockIO(S))->B_2_6_0 = muDoubleScalarSin(((Parameters *)
      ssGetDefaultParam(S))->P_8 * ssGetTaskTime(S,0) + ((Parameters *)
      ssGetDefaultParam(S))->P_9) * ((Parameters *) ssGetDefaultParam(S))->P_6 +
      ((Parameters *) ssGetDefaultParam(S))->P_7;
    ((BlockIO *) _ssGetBlockIO(S))->B_2_7_0 = ((ContinuousStates *)
      ssGetContStates(S))->Integrator1_CSTATE - ((BlockIO *) _ssGetBlockIO(S))
      ->B_2_6_0;
    ((BlockIO *) _ssGetBlockIO(S))->B_2_8_0 = ((ContinuousStates *)
      ssGetContStates(S))->Integrator_CSTATE;
    ((BlockIO *) _ssGetBlockIO(S))->B_2_9_0 = muDoubleScalarSin(((Parameters *)
      ssGetDefaultParam(S))->P_13 * ssGetTaskTime(S,0) + ((Parameters *)
      ssGetDefaultParam(S))->P_14) * ((Parameters *) ssGetDefaultParam(S))->P_11
      + ((Parameters *) ssGetDefaultParam(S))->P_12;
    ((BlockIO *) _ssGetBlockIO(S))->B_2_10_0 = ((BlockIO *) _ssGetBlockIO(S))
      ->B_2_8_0 - ((BlockIO *) _ssGetBlockIO(S))->B_2_9_0;

    /* Clock: '<S7>/Clock' */
    B_2_31_0 = ssGetT(S);
    ((BlockIO *) _ssGetBlockIO(S))->B_2_12_0 = (muDoubleScalarExp(2.0 * B_2_31_0)
      + 3.0) / (3.0 - muDoubleScalarExp(2.0 * B_2_31_0));

    /* Operator : fix */
    B_2_31_0 = ((BlockIO *) _ssGetBlockIO(S))->B_2_12_0 < 0.0 ?
      muDoubleScalarCeil(((BlockIO *) _ssGetBlockIO(S))->B_2_12_0) :
      muDoubleScalarFloor(((BlockIO *) _ssGetBlockIO(S))->B_2_12_0);
    rtAction = -1;
    if (ssIsMajorTimeStep(S) != 0) {
      if (B_2_31_0 == 20.0) {
        rtAction = 0;
      }

      ((D_Work *) ssGetRootDWork(S))->If_ActiveSubsystem = rtAction;
    } else {
      rtAction = ((D_Work *) ssGetRootDWork(S))->If_ActiveSubsystem;
    }

    if (rtAction == 0) {
      if (ssIsSampleHit(S, 1, 0)) {
        ((BlockIO *) _ssGetBlockIO(S))->B_0_0_0 = ((Parameters *)
          ssGetDefaultParam(S))->P_21;
      }

      if (ssIsMajorTimeStep(S)) {
        srUpdateBC(((D_Work *) ssGetRootDWork(S))->IfActionSubsystem_SubsysRanBC);
      }
    }

    if (ssIsSampleHit(S, 1, 0)) {
      ((BlockIO *) _ssGetBlockIO(S))->B_2_16_0 = ((Parameters *)
        ssGetDefaultParam(S))->P_15;
    }

    if (((BlockIO *) _ssGetBlockIO(S))->B_0_0_0 >= ((Parameters *)
         ssGetDefaultParam(S))->P_16) {
      ((BlockIO *) _ssGetBlockIO(S))->B_2_17_0 = ((BlockIO *) _ssGetBlockIO(S)
        )->B_2_12_0;
    } else {
      ((BlockIO *) _ssGetBlockIO(S))->B_2_17_0 = ((BlockIO *) _ssGetBlockIO(S)
        )->B_2_16_0;
    }

    if (ssIsSampleHit(S, 1, 0)) {
      ((BlockIO *) _ssGetBlockIO(S))->B_2_18_0 = ((Parameters *)
        ssGetDefaultParam(S))->P_22;

      /* S-Function (sfblk_manswitch): '<S5>/S-Function' */
      ((BlockIO *) _ssGetBlockIO(S))->B_2_19_0 = ((BlockIO *) _ssGetBlockIO(S)
        )->B_2_18_0;
    }

    /* Clock: '<S6>/Clock' */
    B_2_31_0 = ssGetT(S);
    ((BlockIO *) _ssGetBlockIO(S))->B_2_21_0 = 18.0 / (muDoubleScalarExp(-22.0 *
      B_2_31_0 + 6.0) + 1.0) + 2.0;
    ssCallAccelRunBlock(S, 2, 22, SS_CALL_MDL_OUTPUTS);
    if (ssIsSampleHit(S, 1, 0)) {
      /* Scope: '<Root>/Errors and Landa' */
      /* Call into Simulink for Scope */
      ssCallAccelRunBlock(S, 2, 23, SS_CALL_MDL_OUTPUTS);

      /* Scope: '<Root>/L' */

      /* Call into Simulink for Scope */
      ssCallAccelRunBlock(S, 2, 24, SS_CALL_MDL_OUTPUTS);
    }

    ((BlockIO *) _ssGetBlockIO(S))->B_2_25_0 = muDoubleScalarSin(((Parameters *)
      ssGetDefaultParam(S))->P_19 * ssGetTaskTime(S,0) + ((Parameters *)
      ssGetDefaultParam(S))->P_20) * ((Parameters *) ssGetDefaultParam(S))->P_17
      + ((Parameters *) ssGetDefaultParam(S))->P_18;
    if (ssIsSampleHit(S, 1, 0)) {
      /* Scope: '<Root>/REFs' */
      /* Call into Simulink for Scope */
      ssCallAccelRunBlock(S, 2, 26, SS_CALL_MDL_OUTPUTS);

      /* Level1 S-Function Block: '<S9>/B_1_0' (sfunxy) */
      /* Call into Simulink for MEX-version of S-function */
      ssCallAccelRunBlock(S, 1, 0, SS_CALL_MDL_OUTPUTS);
      ((BlockIO *) _ssGetBlockIO(S))->B_1_3_0[0] = ((BlockIO *) _ssGetBlockIO(S))
        ->B_2_7_0;
      ((BlockIO *) _ssGetBlockIO(S))->B_1_3_0[1] = ((BlockIO *) _ssGetBlockIO(S))
        ->B_2_10_0;

      /* Scope: '<Root>/e' */

      /* Call into Simulink for Scope */
      ssCallAccelRunBlock(S, 2, 28, SS_CALL_MDL_OUTPUTS);

      /* Scope: '<Root>/ed' */

      /* Call into Simulink for Scope */
      ssCallAccelRunBlock(S, 2, 29, SS_CALL_MDL_OUTPUTS);
    }

    B_2_31_0 = (B_2_5_0 - ((BlockIO *) _ssGetBlockIO(S))->B_2_6_0) * ((BlockIO *)
      _ssGetBlockIO(S))->B_2_22_0 + (((BlockIO *) _ssGetBlockIO(S))->B_2_8_0 -
                                     ((BlockIO *) _ssGetBlockIO(S))->B_2_9_0);
    B_2_31_0 = muDoubleScalarSign(B_2_31_0);
    ((BlockIO *) _ssGetBlockIO(S))->B_2_32_0 = ((1.5 * muDoubleScalarPower
      (((BlockIO *) _ssGetBlockIO(S))->B_2_8_0, 2.0) * muDoubleScalarCos(3.0 *
      B_2_5_0) + ((BlockIO *) _ssGetBlockIO(S))->B_2_25_0) - (((BlockIO *)
      _ssGetBlockIO(S))->B_2_8_0 - ((BlockIO *) _ssGetBlockIO(S))->B_2_9_0) *
      ((BlockIO *) _ssGetBlockIO(S))->B_2_22_0) - (0.5 * muDoubleScalarPower
      (((BlockIO *) _ssGetBlockIO(S))->B_2_8_0, 2.0) * muDoubleScalarAbs
      (muDoubleScalarCos(3.0 * B_2_5_0)) + 0.10000000000000001) * B_2_31_0;
    if (ssIsSampleHit(S, 1, 0)) {
      /* Scope: '<Root>/u' */
      /* Call into Simulink for Scope */
      ssCallAccelRunBlock(S, 2, 33, SS_CALL_MDL_OUTPUTS);

      /* Scope: '<S7>/Scope' */

      /* Call into Simulink for Scope */
      ssCallAccelRunBlock(S, 2, 34, SS_CALL_MDL_OUTPUTS);
    }

    ((BlockIO *) _ssGetBlockIO(S))->B_2_35_0 = (-((BlockIO *) _ssGetBlockIO(S)
      )->B_2_3_0) * muDoubleScalarPower(((BlockIO *) _ssGetBlockIO(S))->B_2_8_0,
      2.0) * muDoubleScalarCos(3.0 * B_2_5_0) + ((BlockIO *) _ssGetBlockIO(S))
      ->B_2_32_0;
  }

  /* tid is required for a uniform function interface.
   * Argument tid is not used in the function. */
  UNUSED_PARAMETER(tid);
}

/* Update for root system: '<Root>' */
#define MDL_UPDATE

static void mdlUpdate(SimStruct *S, int_T tid)
{
  if (ssIsSampleHit(S, 1, 0)) {
    /* Level1 S-Function Block: '<S9>/B_1_0' (sfunxy) */
    /* Call into Simulink for MEX-version of S-function */
    ssCallAccelRunBlock(S, 1, 0, SS_CALL_MDL_UPDATE);
  }

  /* tid is required for a uniform function interface.
   * Argument tid is not used in the function. */
  UNUSED_PARAMETER(tid);
}

/* Derivatives for root system: '<Root>' */
#define MDL_DERIVATIVES

static void mdlDerivatives(SimStruct *S)
{
  ((StateDerivatives *) ssGetdX(S))->Integrator1_CSTATE = ((BlockIO *)
    _ssGetBlockIO(S))->B_2_8_0;
  ((StateDerivatives *) ssGetdX(S))->Integrator_CSTATE = ((BlockIO *)
    _ssGetBlockIO(S))->B_2_35_0;
}

/* Function to initialize sizes */
static void mdlInitializeSizes(SimStruct *S)
{
  /* checksum */
  ssSetChecksumVal(S, 0, 288731839U);
  ssSetChecksumVal(S, 1, 2818945451U);
  ssSetChecksumVal(S, 2, 584382891U);
  ssSetChecksumVal(S, 3, 1876577312U);

  /* options */
  ssSetOptions(S, SS_OPTION_EXCEPTION_FREE_CODE);

  /* Accelerator check memory map size match for DWork */
  if (ssGetSizeofDWork(S) != sizeof(D_Work)) {
    ssSetErrorStatus(S,"Unexpected error: Internal DWork sizes do "
                     "not match for accelerator mex file.");
  }

  /* Accelerator check memory map size match for BlockIO */
  if (ssGetSizeofGlobalBlockIO(S) != sizeof(BlockIO)) {
    ssSetErrorStatus(S,"Unexpected error: Internal BlockIO sizes do "
                     "not match for accelerator mex file.");
  }

  /* model parameters */
  _ssSetDefaultParam(S, (real_T *) &rtDefaultParameters);

  /* non-finites */
  rt_InitInfAndNaN(sizeof(real_T));
}

/* Empty mdlInitializeSampleTimes function (never called) */
static void mdlInitializeSampleTimes(SimStruct *S)
{
}

/* Empty mdlTerminate function (never called) */
static void mdlTerminate(SimStruct *S)
{
}

/* MATLAB MEX Glue */
#include "simulink.c"
