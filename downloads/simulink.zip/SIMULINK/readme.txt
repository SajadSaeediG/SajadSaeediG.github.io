Sajad Saeedi

1) Open OptimalSlidingMode.mdl with SIMULINK
2) Choose the simulation method manually, using the manual switch
3) Run the simulation
4) Run PlotResults.m to plot the results